EECE 455 - Carla's CFB and OFB contribution
FOR NOUR / THE GROUP - NOT THE PERSONAL STUDY MATERIALS

WHAT BELONGS IN THE SHARED GITHUB REPOSITORY
  aesmodes/modes.py
  aesmodes/web/static/js/modes.js
  tests/test_cfb_ofb.py
  docs/cfb-ofb-verification.md

IMPORTANT: modes.py and modes.js are SHARED files. If teammates have
edited these files since the original version, do NOT blindly replace them.

RECOMMENDED INTEGRATION (from the shared repository's root folder):
  1. Save/commit your current work, and create a separate branch.
  2. Extract this ZIP somewhere outside the repository.
  3. Apply the included merge_helper/carla-cfb-ofb.patch:
       git apply --check /path/to/merge_helper/carla-cfb-ofb.patch
       git apply /path/to/merge_helper/carla-cfb-ofb.patch
     If the check fails, compare the 4 changes and merge manually.
  4. Run:
       python -m pytest tests/test_cfb_ofb.py -q
       python -m pytest -q
  5. Commit ONLY the four repository paths listed above (not this README or
     the merge_helper folder). Review changed lines before committing.

ALTERNATIVE: If the group repository still exactly matches Nour's starting
snapshot for these two shared files, the four files in the ZIP can be placed
at their matching paths. Do this ONLY after verifying no teammate changes
would be overwritten.

CFB/OFB WORK INCLUDED
  - CFB encryption/decryption loops refactored into a shared helper
  - OFB feedback comments clarified
  - Graphical mode details now show the correct next-block feedback value
  - 50 new focused CFB/OFB tests and a technical verification document

Previously recorded verification from the provided package:
  - Focused tests: 50 passed
  - Entire suite: 151 passed, 7 skipped (Flask/PyCryptodome missing)
  - Offline browser checks: 4 passed (not a live Flask test)

No part of the repository was pushed or merged by generating these ZIPs.
