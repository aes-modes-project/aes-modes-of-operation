# CFB and OFB — implementation and verification

EECE 455/632 | Project 8: AES Again | Assigned section: Carla Doumit

## Implementation

The project implements AES-128 in full 16-byte blocks. CFB-128 and OFB reuse the existing `AES128.encrypt_block` function for **both** encryption and decryption. No external library is used in the encryption implementation.

Let E_K be AES encryption, P_i a plaintext block, C_i a ciphertext block, and O_i the AES output. Both modes start with a 16-byte all-zero IV in the application.

- CFB: C_0 = IV; C_i = P_i XOR E_K(C_{i-1}); P_i = C_i XOR E_K(C_{i-1}). Feedback is ciphertext in both directions. Encryption must be sequential; decryption can be parallelized because the previous ciphertext is already available (the current implementation is sequential).
- OFB: O_0 = IV; O_i = E_K(O_{i-1}); C_i = P_i XOR O_i; P_i = C_i XOR O_i. Feedback is the AES output, independent of the message. Keystream generation is sequential but can be done before the message arrives.

Although these modes can ordinarily handle partial blocks, the project requires zero padding followed by a padding-count byte. A 16-byte aligned message receives an entire extra block ending in 0x10. Decryption validates and removes the padding. The IV override in the Python functions is retained solely for standard-vector tests.

## Changes to the original implementation

- Consolidated the duplicated CFB block loops into `_cfb`, keeping the existing public functions and return types. Encryption feeds back `out`, decryption feeds back `blk`.
- Retained the existing correct OFB implementation and clarified its feedback comments.
- Added an explicit feedback row and explanation to the CFB/OFB block-detail GUI, plus a CFB fixed-IV warning. The diagrams' original chaining arrows were checked, not replaced.
- Added 50 focused tests in `tests/test_cfb_ofb.py`. Other modes, the AES core, shared padding, and the Flask server remain unchanged.

## Example

Key: `2b7e151628aed2a6abf7158809cf4f3c`; IV: 16 zero bytes; text: `ABCDEFGHIJKLMNOPABCDEFGHIJKLMNOP`.

32 message bytes + 16 padding bytes = 48 ciphertext bytes. The first ciphertext block is `3cb528485ffedefb7708bb0bf4551b3f` in both modes. In block 2:

| Field | CFB | OFB |
|---|---|---|
| AES input | `3cb528485ffedefb7708bb0bf4551b3f` | `7df76b0c1ab899b33e42f047b91b546f` |
| AES output | `8bc6d42b86e47a5e3549d10c6b6c3bc3` | `a9dcf5aa138056e259e7be57958e72d8` |
| Ciphertext | `ca84976fc3a23d167c039a4026227493` | `e89eb6ee56c611aa10adf51bd8c03d88` |

The first block matches because both modes start by encrypting the same IV. Block 2 differs because the feedback differs.

## Verification results

| Check | Passed |
|---|---:|
| NIST known-answer encryption and independent ciphertext decryption | 2/2 |
| Zero IV, exact padding and round trips (11 message lengths per mode) | 22/22 |
| Block trace, feedback and AES-encryption-only checks | 4/4 |
| Independent OpenSSL comparisons, both directions | 8/8 |
| Exact bit-error behavior at four positions per mode | 8/8 |
| Invalid inputs/padding, comparison of feedback, JSON and experiment outputs | 6/6 |
| **Total new tests** | **50/50** |

The original suite run passed 101 tests with 7 skips; the updated suite passed 151 tests with 7 skips. Flask and PyCryptodome were unavailable in the test environment. OpenSSL cross-checks ran successfully. A separate offline Chromium test loaded the existing Modes page HTML/JS and supplied actual Python `run_mode` output through a test bridge: all four mode/direction cases displayed correct feedback and ciphertext/plaintext; no JavaScript exceptions. This does not replace an end-to-end Flask test.

For a flip of the least significant bit of the first ciphertext byte of a 64-byte message (bytes 0 through 63, plus a full padding block) with the key above, CFB changed [1, 72, 0, 0, 0] plaintext bits by block; OFB changed [1, 0, 0, 0, 0]. CFB affects the selected bit and the next block if one exists; OFB affects only that bit. Neither mode authenticates ciphertext. Padding checks do not provide authentication.

## Security note

The fixed zero IV is an assignment requirement, not a production recommendation. CFB repeats its first keystream block across messages using the same key and IV; OFB repeats its entire keystream. Real systems require suitable fresh IVs and authenticated encryption.

## Reference

NIST SP 800-38A (2001), §§6.3–6.4 and Appendix F.3.13–F.3.14, F.4.1–F.4.2: https://csrc.nist.gov/pubs/sp/800/38/a/final. The published vectors use a nonzero IV and omit padding, so the encryption test compares the first four output blocks; the independent decryption test disables padding removal.
