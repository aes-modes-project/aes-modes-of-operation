"""Focused verification of CFB-128 and OFB for Project 8."""
import shutil
import subprocess

import pytest

from aesmodes import modes
from aesmodes.explain import bitflip_experiment, run_mode
from aesmodes.padding import PaddingError

KEY = bytes.fromhex('2b7e151628aed2a6abf7158809cf4f3c')
IV = bytes.fromhex('000102030405060708090a0b0c0d0e0f')
PT = bytes.fromhex('6bc1bee22e409f96e93d7e117393172a'
                   'ae2d8a571e03ac9c9eb76fac45af8e51'
                   '30c81c46a35ce411e5fbc1191a0a52ef'
                   'f69f2445df4f9b17ad2b417be66c3710')
# NIST SP 800-38A, F.3.13/F.3.14 and F.4.1/F.4.2 (no padding).
VECTORS = {
    'CFB': bytes.fromhex('3b3fd92eb72dad20333449f8e83cfb4a'
                         'c8a64537a0b3a93fcde3cdad9f1ce58b'
                         '26751f67a3cbb140b1808cf187a4f4df'
                         'c04b05357c5d1c0eeac4c66f9ff7f2e6'),
    'OFB': bytes.fromhex('3b3fd92eb72dad20333449f8e83cfb4a'
                         '7789508d16918f03f53c52dac54ed825'
                         '9740051e9c5fecf64344f7a82260edcc'
                         '304c6528f659c77866a510d9c1d6ae5e'),
}
NAMES = ['CFB', 'OFB']


def functions(name):
    return getattr(modes, name.lower() + '_encrypt'), getattr(modes, name.lower() + '_decrypt')


@pytest.mark.parametrize('name', NAMES)
def test_official_ciphertext_decrypts(name):
    enc, dec = functions(name)
    assert enc(KEY, PT, IV).output[:len(PT)] == VECTORS[name]
    # Decrypt independent published ciphertext, not output from our own encryptor.
    assert dec(KEY, VECTORS[name], IV, strip_padding=False).output == PT


@pytest.mark.parametrize('name', NAMES)
@pytest.mark.parametrize('n', [0, 1, 5, 15, 16, 17, 31, 32, 63, 64, 129])
def test_padding_and_round_trip(name, n):
    enc, dec = functions(name)
    msg = bytes((i * 37) % 256 for i in range(n))
    count = 16 - n % 16
    expected = msg + bytes(count - 1) + bytes([count])
    result = enc(KEY, msg)
    assert result.iv == bytes(16)
    assert result.padded == expected and len(result.output) == len(expected)
    recovered = dec(KEY, result.output)
    assert recovered.iv == bytes(16)
    assert recovered.padded == expected and recovered.output == msg


@pytest.mark.parametrize('name', NAMES)
@pytest.mark.parametrize('operation', ['encrypt', 'decrypt'])
def test_block_trace_feedback(name, operation, monkeypatch):
    enc, dec = functions(name)
    msg = bytes(range(48))
    ciphertext = enc(KEY, msg).output

    def no_inverse(*args, **kwargs):
        pytest.fail('CFB and OFB must not use AES decryption')

    monkeypatch.setattr(modes.AES128, 'decrypt_block', no_inverse)
    result = enc(KEY, msg) if operation == 'encrypt' else dec(KEY, ciphertext)
    aes = modes.AES128(KEY)
    assert result.steps[0].aes_input == bytes(16)
    for i, step in enumerate(result.steps):
        assert step.index == i + 1
        assert step.aes_output == aes.encrypt_block(step.aes_input)
        assert step.xor_with == step.aes_output
        assert step.block_out == bytes(a ^ b for a, b in zip(step.block_in, step.aes_output))
        if i + 1 < len(result.steps):
            feedback = (step.block_in if operation == 'decrypt' else step.block_out) if name == 'CFB' else step.aes_output
            assert result.steps[i + 1].aes_input == feedback
    assert b''.join(s.block_out for s in result.steps) == (result.output if operation == 'encrypt' else result.padded)


@pytest.mark.parametrize('name', NAMES)
@pytest.mark.parametrize('n', [5, 16, 17, 77])
def test_against_openssl(name, n):
    if not shutil.which('openssl'):
        pytest.skip('OpenSSL is not installed')
    enc, dec = functions(name)
    msg = bytes(range(n))
    result = enc(KEY, msg)
    command = ['openssl', 'enc', '-aes-128-' + name.lower(), '-K', KEY.hex(),
               '-iv', '00' * 16, '-nosalt', '-nopad']
    expected = subprocess.run(command, input=result.padded, capture_output=True, check=True).stdout
    assert result.output == expected
    assert dec(KEY, expected).output == msg
    assert subprocess.run(command + ['-d'], input=result.output, capture_output=True, check=True).stdout == result.padded


@pytest.mark.parametrize('name', NAMES)
@pytest.mark.parametrize('offset', [0, 19, 63, 79])
def test_exact_bit_error(name, offset):
    enc, dec = functions(name)
    result = enc(KEY, bytes(range(64)))  # four data blocks and one padding block
    damaged = bytearray(result.output)
    damaged[offset] ^= 4
    recovered = dec(KEY, bytes(damaged), strip_padding=False).output
    delta = bytes(x ^ y for x, y in zip(result.padded, recovered))
    i = offset // 16
    for j in range(len(delta) // 16):
        block = delta[j * 16:(j + 1) * 16]
        if j == i:
            expected = bytearray(16)
            expected[offset % 16] = 4
            assert block == expected
        elif name == 'CFB' and j == i + 1:
            assert any(block)
        else:
            assert block == bytes(16)


@pytest.mark.parametrize('name', NAMES)
def test_invalid_inputs(name):
    enc, dec = functions(name)
    with pytest.raises(ValueError):
        enc(KEY[:-1], b'hello')
    with pytest.raises(ValueError):
        enc(KEY, b'hello', bytes(15))
    with pytest.raises(ValueError):
        dec(KEY, b'')
    with pytest.raises(ValueError):
        dec(KEY, bytes(17))
    ct = bytearray(enc(KEY, b'hello').output)
    ct[-1] ^= 0x0b  # turn the final pad-count byte into zero
    with pytest.raises(PaddingError):
        dec(KEY, bytes(ct))


def test_feedback_difference():
    a, b = bytes(32), bytes([1]) + bytes(31)
    cfb_a, cfb_b = (modes.cfb_encrypt(KEY, msg) for msg in (a, b))
    ofb_a, ofb_b = (modes.ofb_encrypt(KEY, msg) for msg in (a, b))
    assert cfb_a.output[:16] == modes.ofb_encrypt(KEY, a).output[:16]
    assert cfb_a.steps[1].aes_input != cfb_b.steps[1].aes_input
    assert [s.aes_output for s in ofb_a.steps] == [s.aes_output for s in ofb_b.steps]


@pytest.mark.parametrize('name', NAMES)
def test_gui_payload(name):
    msg = 'CFB and OFB feedback demo: two or more blocks.'.encode()
    enc = run_mode(name, 'encrypt', KEY, msg)
    dec = run_mode(name, 'decrypt', KEY, bytes.fromhex(enc['output']))
    assert dec['outputText'] == msg.decode()
    for r in (enc, dec):
        assert r['iv'] == '00' * 16 and r['padCount'] == 16 - len(msg) % 16
        assert r['steps'][0]['aesInput'] == r['iv']
        for s, following in zip(r['steps'], r['steps'][1:]):
            feedback = (s['blockIn'] if r['operation'] == 'decrypt' else s['blockOut']) if name == 'CFB' else s['aesOutput']
            assert following['aesInput'] == feedback
            assert s['aesOutput'] == s['xorWith']


def test_experiment_payload():
    results = bitflip_experiment(KEY, bytes(range(64)), '1', 0, 7)
    counts = {m['mode']: [b['bits'] for b in m['blocks']] for m in results['modes']}
    assert counts['CFB'][0] == 1 and counts['CFB'][1] > 0 and counts['CFB'][2:] == [0, 0, 0]
    assert counts['OFB'] == [1, 0, 0, 0, 0]
